import java.io.File;
import java.net.URL;


public class Example {

	static int x = 5;
	static int y = 10;
	//static int c = a - b;
	
	static int g[][] = new int[5][10];
	
	public static void main(String[] args) {
		
		for(int i=0;i<x;i++) {			
			for(int j=0;j<y;j++) {
				g[i][j] = x+y;
			}
			
		}
		
		
		return; 
	}
	
}
