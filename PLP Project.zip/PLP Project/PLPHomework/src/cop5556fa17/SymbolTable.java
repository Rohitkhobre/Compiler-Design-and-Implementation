package cop5556fa17;


import java.util.*;
import cop5556fa17.AST.Declaration;;

public class SymbolTable {

	HashMap <String, Declaration> SymbolTable;

	public SymbolTable() {
		SymbolTable = new HashMap<>();
	}

	public Declaration lookup(String name){

		Declaration dec = null;

		if (SymbolTable.containsKey(name)) {
			dec = SymbolTable.get(name);
		}
		return dec;
	}

	public void insert(String name, Declaration dec) {

		SymbolTable.put(name, dec);

	}


}
