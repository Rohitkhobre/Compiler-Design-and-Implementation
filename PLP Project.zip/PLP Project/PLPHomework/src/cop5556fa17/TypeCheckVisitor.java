package cop5556fa17;

import cop5556fa17.Scanner.Token;
import cop5556fa17.AST.ASTNode;
import cop5556fa17.AST.ASTVisitor;
import cop5556fa17.AST.Declaration;
import cop5556fa17.AST.Declaration_Image;
import cop5556fa17.AST.Declaration_SourceSink;
import cop5556fa17.AST.Declaration_Variable;
import cop5556fa17.AST.Expression;
import cop5556fa17.AST.Expression_Binary;
import cop5556fa17.AST.Expression_BooleanLit;
import cop5556fa17.AST.Expression_Conditional;
import cop5556fa17.AST.Expression_FunctionAppWithExprArg;
import cop5556fa17.AST.Expression_FunctionAppWithIndexArg;
import cop5556fa17.AST.Expression_Ident;
import cop5556fa17.AST.Expression_IntLit;
import cop5556fa17.AST.Expression_PixelSelector;
import cop5556fa17.AST.Expression_PredefinedName;
import cop5556fa17.AST.Expression_Unary;
import cop5556fa17.AST.Index;
import cop5556fa17.AST.LHS;
import cop5556fa17.AST.Program;
import cop5556fa17.AST.Sink;
import cop5556fa17.AST.Sink_Ident;
import cop5556fa17.AST.Sink_SCREEN;
import cop5556fa17.AST.Source;
import cop5556fa17.AST.Source_CommandLineParam;
import cop5556fa17.AST.Source_Ident;
import cop5556fa17.AST.Source_StringLiteral;
import cop5556fa17.AST.Statement_Assign;
import cop5556fa17.AST.Statement_In;
import cop5556fa17.AST.Statement_Out;
import cop5556fa17.Scanner.Kind;

import java.net.MalformedURLException;
import java.net.URL;

import cop5556fa17.SymbolTable;
import cop5556fa17.TypeUtils.Type;

public class TypeCheckVisitor implements ASTVisitor {
	

		@SuppressWarnings("serial")
		public static class SemanticException extends Exception {
			Token t;

			public SemanticException(Token t, String message) {
				super("line " + t.line + " pos " + t.pos_in_line + ": "+  message);
				this.t = t;
			}

		}		
		
		SymbolTable SymbolTable = new SymbolTable();
	
	/**
	 * The program name is only used for naming the class.  It does not rule out
	 * variables with the same name.  It is returned for convenience.
	 * 
	 * @throws Exception 
	 */
	@Override
	public Object visitProgram(Program program, Object arg) throws Exception {
		for (ASTNode node: program.decsAndStatements) {
			node.visit(this, arg);
		}
		return program.name;
	}

	@Override
	public Object visitDeclaration_Variable(
			Declaration_Variable declaration_Variable, Object arg)
			throws Exception {
		// TODO Auto-generated method stub
		
			Declaration dec = null;			
			dec = SymbolTable.lookup(declaration_Variable.name);
			
			if(dec==null) {
				declaration_Variable.setTypeName(TypeUtils.getType(declaration_Variable.firstToken));
				
			}else {
				throw new SemanticException(declaration_Variable.firstToken, "Name declared already");
			}
			
			if(declaration_Variable.e != null) {
				Expression e1 = (Expression)declaration_Variable.e.visit(this, null);
			
				if(declaration_Variable.getTypeName() != e1.getTypeName()) {
					throw new SemanticException(declaration_Variable.firstToken, "Declaration type not matching to expression within");
				}
			
			}
			
			SymbolTable.insert(declaration_Variable.name, declaration_Variable);
			
			return declaration_Variable;
	}

	@Override
	public Object visitExpression_Binary(Expression_Binary expression_Binary,
			Object arg) throws Exception {
		// TODO Auto-generated method stub
		
		Expression e0 = (Expression) expression_Binary.e0.visit(this, null);
		Expression e1 = (Expression) expression_Binary.e1.visit(this, null);
		
		if(e0.getTypeName()!=e1.getTypeName()) {
			throw new SemanticException(expression_Binary.firstToken, "In visitExpression_Binary expressions have different types");
		}
		
		if(expression_Binary.op == Kind.OP_EQ || expression_Binary.op == Kind.OP_NEQ) {
			expression_Binary.setTypeName(Type.BOOLEAN);
		} else if((expression_Binary.op == Kind.OP_GE || expression_Binary.op == Kind.OP_LE || expression_Binary.op == Kind.OP_GT || expression_Binary.op == Kind.OP_LT) && e0.getTypeName()==Type.INTEGER) {
			expression_Binary.setTypeName(Type.BOOLEAN);
		}else if((expression_Binary.op == Kind.OP_AND || expression_Binary.op == Kind.OP_OR) && (e0.getTypeName()== Type.INTEGER || e0.getTypeName()==Type.BOOLEAN)) {
			expression_Binary.setTypeName(e0.getTypeName());
		}else if((expression_Binary.op == Kind.OP_DIV || expression_Binary.op == Kind.OP_MINUS || expression_Binary.op == Kind.OP_MOD || expression_Binary.op == Kind.OP_PLUS || expression_Binary.op == Kind.OP_POWER || expression_Binary.op == Kind.OP_TIMES) && (e0.getTypeName()==Type.INTEGER)) {
			expression_Binary.setTypeName(Type.INTEGER);
		}else {
			expression_Binary.setTypeName(null);
		}
		
		if(expression_Binary.getTypeName()==null) {
			throw new SemanticException(expression_Binary.firstToken, "expression_Binary type null");
		}
		
		return expression_Binary;
	}

	@Override
	public Object visitExpression_Unary(Expression_Unary expression_Unary,
			Object arg) throws Exception {
		// TODO Auto-generated method stub
		
		Expression e = (Expression) expression_Unary.e.visit(this, null);
		
		if((expression_Unary.op == Kind.OP_EXCL) && (e.getTypeName()==Type.BOOLEAN || e.getTypeName()==Type.INTEGER)) {
			expression_Unary.setTypeName(e.getTypeName());
		}else if((expression_Unary.op == Kind.OP_PLUS || expression_Unary.op == Kind.OP_MINUS) && (e.getTypeName()==Type.INTEGER)) {
			expression_Unary.setTypeName(Type.INTEGER);
		}else {
			expression_Unary.setTypeName(null);
		}
		
		if(expression_Unary.getTypeName()==null) {
			throw new SemanticException(expression_Unary.firstToken, "expression Unary type is null");
		}
		
		return expression_Unary;
	}

	@Override
	public Object visitIndex(Index index, Object arg) throws Exception {
		// TODO Auto-generated method stub
		
		Expression e0 = (Expression) index.e0.visit(this, null);
		Expression e1 = (Expression) index.e1.visit(this, null);
		
		if(e0.getTypeName()!=Type.INTEGER || e1.getTypeName()!=Type.INTEGER) {
			throw new SemanticException(index.firstToken, "Expressions in index are not integer types");
		}
		
		index.setCartesian(!(e0.firstToken.kind== Kind.KW_r && e1.firstToken.kind==Kind.KW_a));
		
		return index;
	}

	@Override
	public Object visitExpression_PixelSelector(
			Expression_PixelSelector expression_PixelSelector, Object arg)
			throws Exception {
		// TODO Auto-generated method stub
		
		Declaration dec = null;
		Type t = null;
		Index i =null;
		
		dec = SymbolTable.lookup(expression_PixelSelector.name);
		
		if(dec == null) {
			throw new SemanticException(expression_PixelSelector.firstToken, "name not declared before thats used in visitExpression_PixelSelector");			
		}
				
		t = dec.getTypeName();
		
		if(expression_PixelSelector.index!=null) {
			i = (Index) expression_PixelSelector.index.visit(this, null);
		}
		
		if(t == Type.IMAGE) {
			expression_PixelSelector.setTypeName(Type.INTEGER);
		}else if(i==null) {
			expression_PixelSelector.setTypeName(t);
		}else {
			expression_PixelSelector.setTypeName(null);
		}
		
		if(expression_PixelSelector.getTypeName()==null) {
			throw new SemanticException(expression_PixelSelector.firstToken, "Expression_pixelSelector type is null");
		}
		
		return expression_PixelSelector;
	}

	@Override
	public Object visitExpression_Conditional(
			Expression_Conditional expression_Conditional, Object arg)
			throws Exception {
		// TODO Auto-generated method stub
					
			Expression cond = (Expression)expression_Conditional.condition.visit(this, null);
			Expression texp = (Expression)expression_Conditional.trueExpression.visit(this, null);
			Expression fexp = (Expression)expression_Conditional.falseExpression.visit(this, null);
			
			if(cond.getTypeName()!= Type.BOOLEAN || (texp.getTypeName()!=fexp.getTypeName())) {
				throw new SemanticException(expression_Conditional.firstToken, "Expression types not as required");
			}
			
			expression_Conditional.setTypeName(texp.getTypeName());
			
			return expression_Conditional;
	}

	
	@Override
	public Object visitDeclaration_Image(Declaration_Image declaration_Image,
			Object arg) throws Exception {
		// TODO Auto-generated method stub
								
			Declaration dec = null;
			
			dec = SymbolTable.lookup(declaration_Image.name);
			
			if(dec == null) {
				declaration_Image.setTypeName(Type.IMAGE);
				
			}else {
				throw new SemanticException(declaration_Image.firstToken, "Name declared before already");
			}
			
			if(declaration_Image.xSize!=null) {
				
				Expression e1 = (Expression)declaration_Image.xSize.visit(this, null);
			
				if(declaration_Image.ySize == null) {
					throw new SemanticException(declaration_Image.firstToken, "No ySize expression");
				}
				Expression e2 = (Expression)declaration_Image.ySize.visit(this, null);	
				
		
				if(e1.getTypeName()!= Type.INTEGER || e2.getTypeName()!= Type.INTEGER) {
					throw new SemanticException(declaration_Image.firstToken, "xSize or ySize expressions have non integer type");

				}
				
			}
			
			if(declaration_Image.source!=null) {
				declaration_Image.source.visit(this, null);
			}
			
			SymbolTable.insert(declaration_Image.name, declaration_Image);
			
			return declaration_Image;
	}
	

	
	
	
	@Override
	public Object visitSource_StringLiteral(
			Source_StringLiteral source_StringLiteral, Object arg)
			throws Exception {
		// TODO Auto-generated method stub
		
	
		String fileorurl = source_StringLiteral.fileOrUrl;
		
		try {
			
			 URL url = new URL(fileorurl);
			
			source_StringLiteral.setTypeName(Type.URL);
			
		}catch(MalformedURLException e) {
			
			source_StringLiteral.setTypeName(Type.FILE);
		}
		
		return source_StringLiteral;
	}

	@Override
	public Object visitSource_CommandLineParam(
			Source_CommandLineParam source_CommandLineParam, Object arg)
			throws Exception {
		// TODO Auto-generated method stub
		
		Expression e = (Expression) source_CommandLineParam.paramNum.visit(this, null);
		
		source_CommandLineParam.setTypeName(null);
		
		if(source_CommandLineParam.paramNum.getTypeName() != Type.INTEGER) {
			throw new SemanticException(source_CommandLineParam.firstToken, "source_CommandLineParam is not of integer type");
		}
		
		return source_CommandLineParam;
	}

	
	@Override
	public Object visitSource_Ident(Source_Ident source_Ident, Object arg)
			throws Exception {
		// TODO Auto-generated method stub
		
		Declaration dec = null;
		dec = SymbolTable.lookup(source_Ident.name);
		
		if(dec == null) {
			throw new SemanticException(source_Ident.firstToken, "In source_Ident Name of variable not declared before");
		}

		source_Ident.setTypeName(dec.getTypeName());
		
		if(source_Ident.getTypeName()!= Type.FILE && source_Ident.getTypeName()!=Type.URL) {
			throw new SemanticException(source_Ident.firstToken, "Source ident type not valid");
		}
		
		return source_Ident;
	}

	@Override
	public Object visitDeclaration_SourceSink(
			Declaration_SourceSink declaration_SourceSink, Object arg)
			throws Exception {
		// TODO Auto-generated method stub
				
			Declaration dec = null;
			
			dec = SymbolTable.lookup(declaration_SourceSink.name);
			
			if(dec == null) {
				declaration_SourceSink.setTypeName(TypeUtils.getType(declaration_SourceSink.firstToken));
				
			} else {
				throw new SemanticException(declaration_SourceSink.firstToken, "Name already declared before");
			}
			
			Source src = (Source)declaration_SourceSink.source.visit(this, null);
			
			if(src.getTypeName()!=declaration_SourceSink.getTypeName() && src.getTypeName()!=null) {
				throw new SemanticException(declaration_SourceSink.firstToken, "Declaration_SourceSink and Source have different types");
			}
			
			SymbolTable.insert(declaration_SourceSink.name, declaration_SourceSink);
			
			return declaration_SourceSink;		
	}

	
	@Override
	public Object visitExpression_IntLit(Expression_IntLit expression_IntLit,
			Object arg) throws Exception {
		// TODO Auto-generated method stub
		
				expression_IntLit.setTypeName(Type.INTEGER);
			
				return expression_IntLit;
	}

	@Override
	public Object visitExpression_FunctionAppWithExprArg(
			Expression_FunctionAppWithExprArg expression_FunctionAppWithExprArg,
			Object arg) throws Exception {
		// TODO Auto-generated method stub
		
		
				Expression e = (Expression) expression_FunctionAppWithExprArg.arg.visit(this, null);
				
				if(e.getTypeName()!= Type.INTEGER) {
					throw new SemanticException(expression_FunctionAppWithExprArg.firstToken, "Arguement Expression is not Integer type");
				}
				
				expression_FunctionAppWithExprArg.setTypeName(Type.INTEGER);
				
				return expression_FunctionAppWithExprArg;		
	}

	@Override
	public Object visitExpression_FunctionAppWithIndexArg(
			Expression_FunctionAppWithIndexArg expression_FunctionAppWithIndexArg,
			Object arg) throws Exception {
		// TODO Auto-generated method stub
		
	
				expression_FunctionAppWithIndexArg.arg.visit(this, null);
				
				expression_FunctionAppWithIndexArg.setTypeName(Type.INTEGER);
				
				return expression_FunctionAppWithIndexArg;		
	}

	@Override
	public Object visitExpression_PredefinedName(
			Expression_PredefinedName expression_PredefinedName, Object arg)
			throws Exception {
		// TODO Auto-generated method stub

				expression_PredefinedName.setTypeName(Type.INTEGER);
			
				return expression_PredefinedName;	
	}

	@Override
	public Object visitStatement_Out(Statement_Out statement_Out, Object arg)
			throws Exception {
		// TODO Auto-generated method stub
		
		
			Declaration dec = null;
			dec = SymbolTable.lookup(statement_Out.name);
			
			
			if (dec == null) {
				throw new SemanticException(statement_Out.firstToken,"Semantic Exception in visitStatement_Out");
			}
			
			statement_Out.setDec(dec);
			
			Sink snk = (Sink)statement_Out.sink.visit(this, null);

			if(((dec.getTypeName()==Type.INTEGER || dec.getTypeName()==Type.BOOLEAN) && snk.getTypeName()==Type.SCREEN) || (dec.getTypeName()==Type.IMAGE &&(snk.getTypeName()==Type.FILE || snk.getTypeName()==Type.SCREEN))) {
				
			}else {
				throw new SemanticException(statement_Out.firstToken,"Semantic Exception in visitStatement_Out");
			}
				
			return statement_Out;			
	}

	@Override
	public Object visitStatement_In(Statement_In statement_In, Object arg)
			throws Exception {
		// TODO Auto-generated method stub
		
		
			Declaration dec = null;
			dec = SymbolTable.lookup(statement_In.name);
			
			statement_In.setDec(dec);
			
			Source sc1 = (Source)statement_In.source.visit(this, null);
			
		//	if((dec == null) || (dec.getTypeName() != sc1.getTypeName())) {
		//		throw new SemanticException(statement_In.firstToken,"Semantic Exception in visitStatement_In");

		//	}
			
			
			return statement_In;
		
	}

	@Override
	public Object visitStatement_Assign(Statement_Assign statement_Assign,
			Object arg) throws Exception {
		// TODO Auto-generated method stub
					
			LHS lhs1 = (LHS)statement_Assign.lhs.visit(this, null);
			Expression e1 = (Expression)statement_Assign.e.visit(this, null);
			//lhs1.getTypeName() != Type.IMAGE
			if(lhs1.getTypeName()!=e1.getTypeName() && !(lhs1.getTypeName()==Type.IMAGE && e1.getTypeName()==Type.INTEGER)) {
				throw new SemanticException(statement_Assign.firstToken, "Semantic Exception in visitStatement_Assign");
			}else {
				statement_Assign.setCartesian(lhs1.isCartesian());
			}
			
			return statement_Assign;		
	}

	@Override
	public Object visitLHS(LHS lhs, Object arg) throws Exception {
		// TODO Auto-generated method stub
		
		Declaration dec = null;
		
		dec = SymbolTable.lookup(lhs.name);
		
		if(dec==null) {
			throw new SemanticException(lhs.firstToken, "Name in LHS is not declared before");
		}
		
		lhs.setDec(dec);
		
		lhs.setTypeName(lhs.getDec().getTypeName());
		
		if(lhs.index!=null) {
			Index i = (Index) lhs.index.visit(this, null);	
			lhs.setCartesian(i.isCartesian());
		}
		
		return lhs;
	}

	
	@Override
	public Object visitSink_SCREEN(Sink_SCREEN sink_SCREEN, Object arg)
			throws Exception {
		// TODO Auto-generated method stub
		
		sink_SCREEN.setTypeName(Type.SCREEN);
		
		return sink_SCREEN;
	}

	@Override
	public Object visitSink_Ident(Sink_Ident sink_Ident, Object arg)
			throws Exception {
		// TODO Auto-generated method stub
		
		Declaration dec = null;
		dec = SymbolTable.lookup(sink_Ident.name);
		
		if(dec == null) {
			throw new SemanticException(sink_Ident.firstToken, "In visitSink_Ident Sink name not declared before");
		}
		
		sink_Ident.setTypeName(dec.getTypeName());
		
		if(sink_Ident.getTypeName()!= Type.FILE) {
			throw new SemanticException(sink_Ident.firstToken, "In visitSink_Ident sink_Ident type is not file");
		}
		
		return sink_Ident;
	}

	
	@Override
	public Object visitExpression_BooleanLit(
			Expression_BooleanLit expression_BooleanLit, Object arg)
			throws Exception {
		
		// TODO Auto-generated method stub
		
			expression_BooleanLit.setTypeName(Type.BOOLEAN);
			return expression_BooleanLit;
		
	}

	@Override
	public Object visitExpression_Ident(Expression_Ident expression_Ident,
			Object arg) throws Exception {
		
		// TODO Auto-generated method stub
			
			Declaration dec = null;	
		
			dec = SymbolTable.lookup(expression_Ident.name);
			
			if(dec!=null) {
				expression_Ident.setTypeName(dec.getTypeName());
			}else {
				throw new SemanticException(expression_Ident.firstToken, "identifier Not declared before");
			}
			
			return expression_Ident;
		
	}

}
