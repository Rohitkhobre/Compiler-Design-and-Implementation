package cop5556fa17.AST;

import cop5556fa17.TypeUtils;
import cop5556fa17.Scanner.Token;
import cop5556fa17.TypeUtils.Type;

public abstract class Source extends ASTNode{

	Type typeName;
	
	public Source(Token firstToken) {
		super(firstToken);
	}
	
	
public void setTypeName(Type type) {
		
			this.typeName = type;

	}
	
	public Type getTypeName() {
	
		return typeName;
	}
	
	
}
