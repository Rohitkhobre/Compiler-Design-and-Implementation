package cop5556fa17.AST;

import cop5556fa17.Scanner.Token;

public abstract class Expression_FunctionApp extends Expression {

	public Expression_FunctionApp(Token firstToken) {
		super(firstToken);
		
	}

}
