package cop5556fa17;

import cop5556fa17.AST.*;

import java.util.ArrayList;
import java.util.Arrays;

import cop5556fa17.Scanner.Kind;
import cop5556fa17.Scanner.Token;
import cop5556fa17.Parser.SyntaxException;

import static cop5556fa17.Scanner.Kind.*;

public class Parser {

	@SuppressWarnings("serial")
	public class SyntaxException extends Exception {
		Token t;

		public SyntaxException(Token t, String message) {
			super(message);
			this.t = t;
		}

	}


	Scanner scanner;
	Token t;

	Parser(Scanner scanner) {
		this.scanner = scanner;
		t = scanner.nextToken();
	}

	/**
	 * Main method called by compiler to parser input.
	 * Checks for EOF
	 * @return 
	 * 
	 * @throws SyntaxException
	 */
	public Program parse() throws SyntaxException {

		Program ast = program();
		matchEOF();
		
		return ast;
	}
	

	/**
	 * Program ::=  IDENTIFIER   ( Declaration SEMI | Statement SEMI )*   
	 * 
	 * Program is start symbol of our grammar.
	 * 
	 * @throws SyntaxException
	 */
	Program program() throws SyntaxException {
		//TODO  implement this
		
		//throw new UnsupportedOperationException();
		
		Token first = t;
		Token name = null;
		ArrayList<ASTNode> decsAndStets = new ArrayList<>();
		
		Declaration dec = null;
		Statement statemnt = null;
		
		Program anode = null;
		
		if(t.kind == IDENTIFIER) {
			name = t;
			consume();
		} else {
			throw new SyntaxException(t,"No IDENTIFIER TOKEN found in Program");
		}
		
		
		while(t.kind == IDENTIFIER || t.kind == KW_int || t.kind == KW_boolean || t.kind == KW_image || t.kind == KW_url || t.kind == KW_file) {
			
			if(t.kind == IDENTIFIER) {
				
				statemnt = statement();
				decsAndStets.add(statemnt);
				
				if(t.kind == SEMI) {
					consume();
				}else {
					throw new SyntaxException(t,"No SEMI token found in Program");
				}
			}
			
			else {
					dec = declaration();
					decsAndStets.add(dec);
					
					if(t.kind == SEMI) {
						consume();
					}else {
						throw new SyntaxException(t,"No SEMI token found in Program");
					}				
			}				
			
		}
		
		
		anode = new Program(first, name, decsAndStets);
		
		return anode;
	}

	
	
	
	
	
	
	Declaration declaration() throws SyntaxException{
		
		Declaration dec = null;
		
		if(t.kind == KW_int || t.kind == KW_boolean) {
			dec = variableDeclaration();
		} else if(t.kind == KW_image) {
			dec = imageDeclaration();
		}else if(t.kind == KW_url || t.kind == KW_file) {
			dec = sourceSinkDeclaration();
		}else {
			throw new SyntaxException(t,"Wrong token for type in Declaration");
		}
		
		return dec;
	}
	
	
	Declaration variableDeclaration() throws SyntaxException{
		
		Token first = t;
		Token type = null;
		Token name = null;
		Expression e = null;
		Declaration dec = null;
		
		
		type = varType();
		
		if(t.kind == IDENTIFIER) {
			name = t;
			consume();
		} else {
			throw new SyntaxException(t,"No IDENTIFIER found in VariableDeclaration");
		}
		
		
		if(t.kind == OP_ASSIGN) {
			
			consume();
			
			e = expression();
		}
		
		dec = new Declaration_Variable(first, type, name, e);
		
		return dec;
		
	}
	
	
	Token varType() throws SyntaxException{
		
		Token tk = null;
		
		if(t.kind == KW_int || t.kind == KW_boolean) {
			tk = t;
			consume();
		}else {
			throw new SyntaxException(t,"No valid token found in VarType");
		}
		return tk;
	}
	

	Declaration sourceSinkDeclaration() throws SyntaxException{
		
		Token first = t;
		Token type = null;
		Token name = null;
		Source srce = null;
		Declaration dec = null;
		
		type = sourceSinkType();
		
		
		if(t.kind == IDENTIFIER) {
			name = t;
			consume();
		} else {
			throw new SyntaxException(t,"No IDENTIFIER found in SourceSinkDeclaration");
		}
		
		
		if(t.kind == OP_ASSIGN) {
			consume();
		} else {
			throw new SyntaxException(t,"No OP_ASSIGN found in SourceSinkDeclaration");
		}
		
		
		srce = source();
		
		dec = new Declaration_SourceSink(first,type,name,srce);
		
		return dec;
	}
	
	
	Token sourceSinkType() throws SyntaxException{
		
		Token tk = null;
		
		if(t.kind == KW_url || t.kind == KW_file) {
			tk = t;
			consume();
		}else {
			throw new SyntaxException(t,"Not valid token in SourceSinkType ");
		}
		
		return tk;
	}
	
	
	Declaration imageDeclaration() throws SyntaxException{
		
		Token first = t;
		Expression xSize = null;
		Expression ySize = null;
		Token name = null;
		Source srce = null;
		Declaration dec = null;
		
		if(t.kind == KW_image) {
			consume();
		} else {
			throw new SyntaxException(t,"No KW_image found in Image Declaration");
		}
		
		
		if(t.kind == LSQUARE) {
			
			consume();
			
			xSize = expression();
			
			if(t.kind == COMMA) {
				consume();
			} else {
				throw new SyntaxException(t,"No COMMA found in Image Declaration");
			}
			
			
			ySize = expression();
			
			if(t.kind == RSQUARE) {
				consume();
			} else {
				throw new SyntaxException(t,"No RSQUARE found in Image Declaration");
			}			
		
		}
		
		
		if(t.kind == IDENTIFIER) {
			name = t;
			consume();
		} else {
			throw new SyntaxException(t,"No IDENTIFIER found in Image Declaration");
		}
		
		
		
		if(t.kind == OP_LARROW) {
			
			consume();
			
			srce = source();
		}
		
		
		dec = new Declaration_Image(first,xSize,ySize,name,srce);
		
		return dec;
	}
	
	//Do we have to throw Exception here
	Statement statement() throws SyntaxException{
		
		Statement statemnt = null;
		
		Token ident = t;
		if(t.kind == IDENTIFIER) {
			consume();
		} else {
			throw new SyntaxException(t,"No IDENTIFIER START for statement");
		}
		
		if(t.kind == OP_RARROW) {
			statemnt = imageOutStatement(ident);
		} else if(t.kind == OP_LARROW) {
			statemnt = imageInStatement(ident);
		} else {
			statemnt = assignmentStatement(ident);
		}		
		
		return statemnt;
	}
	
	
	Statement imageOutStatement(Token ident) throws SyntaxException{
		
		Token first = ident;
		Token name = ident;
		Sink snk = null;
		Statement statemnt = null;
		if(t.kind == OP_RARROW) {
			consume();
		} else {
			throw new SyntaxException(t,"No OP_RARROW found in ImageOutStatement");
		}
		
		snk = sink();
		
		statemnt = new Statement_Out(first,name,snk);
		
		return statemnt;
	}
	
	//Check for identifier should be type of file
	Sink sink() throws SyntaxException{
		
		Token first = t;
		Sink snk = null;
		
		if(t.kind == IDENTIFIER) {
			Token name = t;
			snk = new Sink_Ident(first,name);
			consume();
		} else if(t.kind == KW_SCREEN) {
			
			snk = new Sink_SCREEN(first);
			consume();
		} else {
			throw new SyntaxException(t,"No valid token found for sink");
		}
		
		return snk;
	}
	
	
	Source source() throws SyntaxException{
		
		Token first = t;
		Source srce = null;
		
		if(t.kind == IDENTIFIER) {
			Token name = t;
			srce = new Source_Ident(first,name);
			consume();
		} else if(t.kind == OP_AT) {
			consume();
			Expression e0 = null;
			e0 = expression();
			srce = new Source_CommandLineParam(first,e0);
		} else if(t.kind == STRING_LITERAL) {
			
			srce = new Source_StringLiteral(first,t.getText());
			consume();
		}else {
			throw new SyntaxException(t,"No valid start found in source");
		}		
		
		return srce;
	}

	
	Statement imageInStatement(Token ident) throws SyntaxException{
		
		Token first = ident;
		Statement statemnt = null;
		Source srce = null;
		
		Token name = ident;
		
		if(t.kind == OP_LARROW) {
			consume();
		} else {
			throw new SyntaxException(t,"No OP_LARROW found in ImageInStatement");
		}
		
		
		srce = source();
		
		statemnt = new Statement_In(first,name,srce);
		
		return statemnt;
	}
	
	
	Statement assignmentStatement(Token ident) throws SyntaxException{
		
		Token first = ident;
		Statement statemnt = null;
		LHS lhs1 = null;
		Expression e0 = null;
		
		lhs1 = lhs(ident);
		
		if(t.kind == OP_ASSIGN) {
			consume();
		} else {
			throw new SyntaxException(t,"No OP_ASSIGN in AssignmentStatement");
		}
		
		e0 = expression();
		
		statemnt = new Statement_Assign(first,lhs1,e0);
		
		return statemnt;
	}
	
	
	Expression orExpression() throws SyntaxException{
		
		Expression e0 = null;
		Expression e1 = null;
		Token first = t;
		Token op = null;
		
		e0 = andExpression();
		
		while(t.kind == OP_OR) {
			op = t;
			consume();
			
			e1 = andExpression();
			
			e0 = new Expression_Binary(first,e0,op,e1);
		}
		
		return e0;
	}
	
	
	Expression andExpression() throws SyntaxException{
		
		Expression e0 = null;
		Expression e1 = null;
		Token first = t;
		Token op = null;
		
		e0 = eqExpression();
		
		while(t.kind == OP_AND) {
			op = t;
			consume();
			
			e1 = eqExpression();
			
			e0 = new Expression_Binary(first,e0,op,e1);
		}
			
		return e0;
	}
	
	
	Expression eqExpression() throws SyntaxException{
		
		Expression e0 = null;
		Expression e1 = null;
		Token first = t;
		Token op = null;
		
		e0 = relExpression();
		
		while(t.kind == OP_EQ || t.kind == OP_NEQ) {
			op = t;
			consume();
			
			e1 = relExpression();
			e0 = new Expression_Binary(first,e0,op,e1);
		}
		
		return e0;
	}
	
	
	Expression relExpression() throws SyntaxException{
		
		Expression e0 = null;
		Expression e1 = null;
		Token first = t;
		Token op = null;
		
		e0 = addExpression();
		
		while(t.kind == OP_LT  || t.kind == OP_GT ||  t.kind == OP_LE  || t.kind == OP_GE ) {
			
			op = t;
			consume();
			
			e1 = addExpression();
			e0 = new Expression_Binary(first,e0,op,e1);
		}
		
		return e0;
	}
	

	Expression addExpression() throws SyntaxException{
		
		Expression e0 = null;
		Expression e1 = null;
		Token first = t;
		Token op = null;
		
		e0 = multExpression();
		
		while(t.kind == OP_PLUS || t.kind == OP_MINUS ) {
			
			op = t;
			consume();
			
			e1 = multExpression();
			e0 = new Expression_Binary(first,e0,op,e1);
		}
		
		return e0;
	}
	
	
	Expression multExpression() throws SyntaxException{
		
		Expression e0 = null;
		Expression e1 = null;
		Token first = t;
		Token op = null;
		
		e0 = unaryExpression();
		
		while(t.kind == OP_TIMES || t.kind == OP_DIV  || t.kind == OP_MOD ) {
			
			op = t;
			
			consume();
			
			e1= unaryExpression();
			e0 = new Expression_Binary(first,e0,op,e1);
		}
		
		return e0;
	}
	
	
	Expression unaryExpression() throws SyntaxException{
		
		Expression e0 = null;
		Token op = null;
		Token first = t;
		
		
		if(t.kind == OP_PLUS) {
			op = t;
			consume();
			e0 = unaryExpression();
			e0 = new Expression_Unary(first,op,e0);
		} else if(t.kind == OP_MINUS) {
			op = t;
			consume();
			e0 = unaryExpression();
			e0 = new Expression_Unary(first,op,e0);
		}else
			e0 = unaryExpressionNotPlusMinus();
		
		return e0;
	}
	
	
	Expression unaryExpressionNotPlusMinus() throws SyntaxException{
		
		Expression e = null;
		Token first = t;
		
		
		
		if( t.kind == KW_x || t.kind == KW_y || t.kind ==KW_r || t.kind ==KW_a || t.kind ==KW_X || t.kind ==KW_Y || t.kind ==KW_Z || t.kind ==KW_A || t.kind ==KW_R || t.kind ==KW_DEF_X || t.kind ==KW_DEF_Y) {
			Kind kind = t.kind;
			e = new Expression_PredefinedName(first,kind);
			consume();
		} else if(t.kind == IDENTIFIER) {
			e = identOrPixelSelectorExpression();
		} else if(t.kind == INTEGER_LITERAL || t.kind == LPAREN || t.kind == KW_sin || t.kind ==KW_cos || t.kind ==KW_atan || t.kind ==KW_abs || t.kind ==KW_cart_x || t.kind ==KW_cart_y || t.kind ==KW_polar_a || t.kind ==KW_polar_r || t.kind == BOOLEAN_LITERAL) {
			e = primary();
		} else if(t.kind == OP_EXCL) {
			Token op = t;
			consume();
			Expression e0 = null;
			e0 = unaryExpression();
			e = new Expression_Unary(first,op,e0);
		} else {
			throw new SyntaxException(t,"Wrong token start for UnaryExpressionNotPlusMinus");
		}
		
		return e;
	}
	
	
	Expression primary() throws SyntaxException{
		
		Expression e = null;
		Token first = t;
		
		if(t.kind == INTEGER_LITERAL) {
			
			e = new Expression_IntLit(first,t.intVal());
			consume();
		} else if(t.kind == LPAREN) {
			
			consume();
			
			e = expression();
			
			if(t.kind == RPAREN) {
				consume();
			} else {
				throw new SyntaxException(t,"Missing RPAREN in Pramary");
			}
			
		}else if(t.kind == BOOLEAN_LITERAL) {
			
			//////// how to get boolean value 
			String str = t.getText();
			Boolean bool = null;
			if(str.equalsIgnoreCase("true")) {
				bool = true;
			} else {
				bool = false;
			}
			
			e = new Expression_BooleanLit(first,bool);
			consume();
			
		}else if(t.kind == KW_sin || t.kind ==KW_cos || t.kind ==KW_atan || t.kind ==KW_abs || t.kind ==KW_cart_x || t.kind ==KW_cart_y || t.kind ==KW_polar_a || t.kind ==KW_polar_r) {
			
			e = functionApplication();
		}else {
			throw new SyntaxException(t,"Wrong starting token for Primary");
		}
			
		
		return e;
	}
	

	Expression identOrPixelSelectorExpression() throws SyntaxException{
		
		Expression ex = null;
		Token first = t;
		Token ident = null;
		Index indx =null;
		
		if(t.kind == IDENTIFIER) {
			ident = t;
			consume();
			
			ex = new Expression_Ident(first,ident);
			
		} else {
			throw new SyntaxException(t,"No IDENTIFIER token found at start of IdentOrPixelSelectorExpression");
		}
		
		if(t.kind == LSQUARE) {
			consume();
			
			indx = selector();
			
			ex = new Expression_PixelSelector(first,ident,indx);
			
			if(t.kind == RSQUARE) {
				consume();				
			}else {
				throw new SyntaxException(t,"No RSQAURE token in Lhs");
			}
		}
		
		return ex;
		
	}
	

	LHS lhs(Token ident) throws SyntaxException{
		
		//Token first = t;
		
		Token first = ident;
		Token name = ident;
		Index indx = null;
		LHS lhs1 = null;
		
		if(t.kind == LSQUARE) {
			consume();
			
			indx = lhsSelector();
			
			if(t.kind == RSQUARE) {
				consume();				
			}else {
				throw new SyntaxException(t,"No RSQAURE token in Lhs");
			}
		}
		
		lhs1 = new LHS(first,name,indx);
		
		return lhs1;
		
	}
	
	
	Expression functionApplication() throws SyntaxException{
		
		Token first = t;
		Expression e0 = null;
		Index indx = null;
		Kind kind = null;
		Expression e = null;
		
		
		kind = functionName();
		
		if(t.kind == LPAREN || t.kind == LSQUARE) {
			
			if(t.kind == LPAREN) {
				consume();
				
				e0 = expression();
				
				e = new Expression_FunctionAppWithExprArg(first,kind,e0);
				
				if(t.kind == RPAREN)
					consume();
				else
					throw new SyntaxException(t,"No RPAREN found in FunctionApplication");
			}
			else {
				consume();
				
				indx = selector();
				
				e = new Expression_FunctionAppWithIndexArg(first,kind,indx);
				
				if(t.kind == RSQUARE)
					consume();
				else
					throw new SyntaxException(t,"No RSQUARE found in FunctionApplication");
			}
			
		}else {
			throw new SyntaxException(t,"No LPAREN or LSQUARE found in FunctionApplication");
		}
		
		return e;
	}
	
	
	Kind functionName() throws SyntaxException{
		
		Kind kind = null;
		
		if(t.kind == KW_sin || t.kind ==KW_cos || t.kind ==KW_atan || t.kind ==KW_abs || t.kind ==KW_cart_x || t.kind ==KW_cart_y || t.kind ==KW_polar_a || t.kind ==KW_polar_r) {
			kind = t.kind;
			consume();
		}else {
			throw new SyntaxException(t,"Syntax Error in FunctionName");
		}
		
		return kind;
	}
	
	
	Index lhsSelector() throws SyntaxException{
		
		Index indx = null;
		
		if(t.kind == LSQUARE){
			consume();
			
			if(t.kind == KW_x || t.kind == KW_r) {
				
				if(t.kind == KW_x)
					indx = xySelector();
				else
					indx = raSelector();
				
				if(t.kind == RSQUARE) {
					consume();
				}else {
					throw new SyntaxException(t,"No RSQUARE in LhsSelector");
				}
				
			}else {
				throw new SyntaxException(t,"No XySelector or RaSelector found in LhsSelector");
			}
			
		}else {
			throw new SyntaxException(t,"LhsSelector not starting with LSQUARE");
		}
		
		return indx;
	}
	
	
	Index xySelector() throws SyntaxException{
		
		Expression e0 = null;
		Expression e1 = null;
		Token first = t;
		Index indx = null;
		
		if(t.kind == KW_x) {
			e0 = new Expression_PredefinedName(first,t.kind);
			consume();
			if(t.kind == COMMA) {
				consume();			
				if(t.kind == KW_y) {
					e1 = new Expression_PredefinedName(t,t.kind);
					consume();	
					
					indx = new Index(first, e0, e1);
					
				}else {
					throw new SyntaxException(t,"No KW_y after comma in RaSelector");
				}				
			} else {
				throw new SyntaxException(t,"No comma after KW_r in RaSelector");
			}			
		}else {
			throw new SyntaxException(t,"RaSelector not starting with KW_x");
		}
		
		return indx;
	}

	
	Index raSelector() throws SyntaxException{
		Expression e0 = null;
		Expression e1 = null;
		Token first = t;
		Index indx = null;
		if(t.kind == KW_r) {
			e0 = new Expression_PredefinedName(first,t.kind);
			consume();
			if(t.kind == COMMA) {
				consume();			
				if(t.kind == KW_a) {
					e1 = new Expression_PredefinedName(t,t.kind);
					consume();
					
					indx = new Index(first, e0, e1);
					
				}else {
					throw new SyntaxException(t,"No KW_A after comma in RaSelector");
				}				
			} else {
				throw new SyntaxException(t,"No comma after KW_r in RaSelector");
			}			
		}else {
			throw new SyntaxException(t,"RaSelector not starting with KW_r");
		}	
		
		return indx;
	}

	
	Index selector() throws SyntaxException{
	
		Token first = t;
		Expression e0 = null;
		Expression e1 = null;
		Index indx = null;
		
		e0 = expression();
		
		if(t.kind == COMMA) {
			consume();
		}else {
			throw new SyntaxException(t,"No COMMA between expressions in selector");
		}
		
		e1 = expression();	
	
		indx = new Index(first,e0,e1);
		
		return indx;
	}
	
	
	/**
	 * Expression ::=  OrExpression  OP_Q  Expression OP_COLON Expression    | OrExpression
	 * 
	 * Our test cases may invoke this routine directly to support incremental development.
	 * 
	 * @throws SyntaxException
	 */
	
	Expression expression() throws SyntaxException {
		//TODO implement this.
		//throw new UnsupportedOperationException();
		
		Expression e0 = null;
		Expression e1 = null;
		Expression e2 = null;
	
		Token first = t;
		
		e0 = orExpression();
		
		if(t.kind == OP_Q) {
			consume();
		
			e1 = expression();
			
			if(t.kind == OP_COLON) {
				consume();
			} else {
				throw new SyntaxException(t,"OP_COLON not found in expression");
			}
		
			e2 = expression();
		
			e0 = new Expression_Conditional(first, e0,e1,e2);
		}
				
		
		return e0;
	}



	/**
	 * Only for check at end of program. Does not "consume" EOF so no attempt to get
	 * nonexistent next Token.
	 * 
	 * @return
	 * @throws SyntaxException
	 */
	private Token matchEOF() throws SyntaxException {
		if (t.kind == EOF) {
			return t;
		}
		String message =  "Expected EOL at " + t.line + ":" + t.pos_in_line;
		throw new SyntaxException(t, message);
	}
	
	private void consume() throws SyntaxException {
	//	Token temp = t;
		t = scanner.nextToken();
	//	return temp;
	}

	
}
