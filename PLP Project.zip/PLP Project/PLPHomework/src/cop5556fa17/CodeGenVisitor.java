package cop5556fa17;

import java.util.ArrayList;
import java.lang.Math;

import org.objectweb.asm.ClassWriter;
import org.objectweb.asm.FieldVisitor;
import org.objectweb.asm.Label;
import org.objectweb.asm.MethodVisitor;
import org.objectweb.asm.Opcodes;

import cop5556fa17.Scanner.Kind;
import cop5556fa17.TypeUtils.Type;
import cop5556fa17.AST.ASTNode;
import cop5556fa17.AST.ASTVisitor;
import cop5556fa17.AST.Declaration;
import cop5556fa17.AST.Declaration_Image;
import cop5556fa17.AST.Declaration_SourceSink;
import cop5556fa17.AST.Declaration_Variable;
import cop5556fa17.AST.Expression;
import cop5556fa17.AST.Expression_Binary;
import cop5556fa17.AST.Expression_BooleanLit;
import cop5556fa17.AST.Expression_Conditional;
import cop5556fa17.AST.Expression_FunctionAppWithExprArg;
import cop5556fa17.AST.Expression_FunctionAppWithIndexArg;
import cop5556fa17.AST.Expression_Ident;
import cop5556fa17.AST.Expression_IntLit;
import cop5556fa17.AST.Expression_PixelSelector;
import cop5556fa17.AST.Expression_PredefinedName;
import cop5556fa17.AST.Expression_Unary;
import cop5556fa17.AST.Index;
import cop5556fa17.AST.LHS;
import cop5556fa17.AST.Program;
import cop5556fa17.AST.Sink_Ident;
import cop5556fa17.AST.Sink_SCREEN;
import cop5556fa17.AST.Source;
import cop5556fa17.AST.Source_CommandLineParam;
import cop5556fa17.AST.Source_Ident;
import cop5556fa17.AST.Source_StringLiteral;
import cop5556fa17.AST.Statement_In;
import cop5556fa17.AST.Statement_Out;
import cop5556fa17.AST.Statement_Assign;
//import cop5556fa17.image.ImageFrame;
//import cop5556fa17.image.ImageSupport;


public class CodeGenVisitor implements ASTVisitor, Opcodes {

	/**
	 * All methods and variable static.
	 */


	/**
	 * @param DEVEL
	 *            used as parameter to genPrint and genPrintTOS
	 * @param GRADE
	 *            used as parameter to genPrint and genPrintTOSF
	 * @param sourceFileName
	 *            name of source file, may be null.
	 */
	public CodeGenVisitor(boolean DEVEL, boolean GRADE, String sourceFileName) {
		super();
		this.DEVEL = DEVEL;
		this.GRADE = GRADE;
		this.sourceFileName = sourceFileName;
	}

	ClassWriter cw;
	String className;
	String classDesc;
	String sourceFileName;

	MethodVisitor mv; // visitor of method currently under construction

	/** Indicates whether genPrint and genPrintTOS should generate code. */
	final boolean DEVEL;
	final boolean GRADE;
	


	@Override
	public Object visitProgram(Program program, Object arg) throws Exception {
		cw = new ClassWriter(ClassWriter.COMPUTE_FRAMES);
		className = program.name;  
		classDesc = "L" + className + ";";
		String sourceFileName = (String) arg;
		cw.visit(52, ACC_PUBLIC + ACC_SUPER, className, null, "java/lang/Object", null);
		cw.visitSource(sourceFileName, null);
		// create main method
		mv = cw.visitMethod(ACC_PUBLIC + ACC_STATIC, "main", "([Ljava/lang/String;)V", null, null);
		// initialize
		mv.visitCode();		
		//add label before first instruction
		Label mainStart = new Label();
		mv.visitLabel(mainStart);		
		// if GRADE, generates code to add string to log
		//CodeGenUtils.genLog(GRADE, mv, "entering main");

		// visit decs and statements to add field to class
		//  and instructions to main method, respectivley
		ArrayList<ASTNode> decsAndStatements = program.decsAndStatements;
		for (ASTNode node : decsAndStatements) {
			node.visit(this, arg);
		}

		//generates code to add string to log
		//CodeGenUtils.genLog(GRADE, mv, "leaving main");
		
		//adds the required (by the JVM) return statement to main
		mv.visitInsn(RETURN);
		
		//adds label at end of code
		Label mainEnd = new Label();
		mv.visitLabel(mainEnd);
		
		//handles parameters and local variables of main. Right now, only args
		mv.visitLocalVariable("args", "[Ljava/lang/String;", null, mainStart, mainEnd, 0);
		
		mv.visitLocalVariable("x", "I", null, mainStart, mainEnd, 1);
		mv.visitLocalVariable("y", "I", null, mainStart, mainEnd, 2);
		mv.visitLocalVariable("X", "I", null, mainStart, mainEnd, 3);
		mv.visitLocalVariable("Y", "I", null, mainStart, mainEnd, 4);
		mv.visitLocalVariable("r", "I", null, mainStart, mainEnd, 5);
		mv.visitLocalVariable("a", "I", null, mainStart, mainEnd, 6);
		mv.visitLocalVariable("R", "I", null, mainStart, mainEnd, 7);
		mv.visitLocalVariable("A", "I", null, mainStart, mainEnd, 8);
		
		FieldVisitor fv = cw.visitField(ACC_STATIC, "DEF_X", "I", null, new Integer(256));
		FieldVisitor fv1 = cw.visitField(ACC_STATIC, "DEF_Y", "I", null, new Integer(256));
		FieldVisitor fv2 = cw.visitField(ACC_STATIC, "Z", "I", null, new Integer(16777215));
		
		//mv.visitLocalVariable("DEF_X", "I", null, mainStart, mainEnd, 9);
		
		//mv.visitVarInsn(ALOAD, 9);
		//mv.visitLdcInsn(256);
		//mv.visitFieldInsn(PUTFIELD, className, "DEF_X", "I");
		
		//mv.visitLocalVariable("DEF_Y", "I", null, mainStart, mainEnd, 10);
		//mv.visitVarInsn(ALOAD, 10);
		//mv.visitLdcInsn(256);		
		//mv.visitFieldInsn(PUTFIELD, className, "DEF_Y", "I");
		
		//mv.visitLocalVariable("Z", "I", null, mainStart, mainEnd, 11);
		//mv.visitVarInsn(ALOAD, 11);
		//mv.visitLdcInsn(16777215);
		//mv.visitFieldInsn(PUTFIELD, className, "Z", "I");
		

		//Sets max stack size and number of local vars.
		//Because we use ClassWriter.COMPUTE_FRAMES as a parameter in the constructor,
		//asm will calculate this itself and the parameters are ignored.
		//If you have trouble with failures in this routine, it may be useful
		//to temporarily set the parameter in the ClassWriter constructor to 0.
		//The generated classfile will not be correct, but you will at least be
		//able to see what is in it.
		
		mv.visitMaxs(0,8);
		
		//terminate construction of main method
		mv.visitEnd();
		
		//terminate class construction
		cw.visitEnd();

		//generate classfile as byte array and return
		return cw.toByteArray();
	}

	@Override
	public Object visitDeclaration_Variable(Declaration_Variable declaration_Variable, Object arg) throws Exception {
		// TODO 
		String fieldName ="";
		String fieldType = "";
		Object initValue;
		FieldVisitor fv;
		
		try {	
		
		fieldName = declaration_Variable.name;
		
		if(declaration_Variable.getTypeName() == Type.INTEGER) {
			fieldType = "I";
			//initValue = new Integer();
		} else if(declaration_Variable.getTypeName() == Type.BOOLEAN) { //if(declaration_Variable.type.kind == Kind.BOOLEAN_LITERAL) {
			fieldType = "Z";
			//initValue = new Boolean(false);
		}
		
		
		fv = cw.visitField(ACC_STATIC, fieldName, fieldType, null, null);
		
		//mv.visitVarInsn(ALOAD, 0);
				
		if(declaration_Variable.e!=null) {
			declaration_Variable.e.visit(this, arg);
			
			mv.visitFieldInsn(PUTSTATIC, className, fieldName, fieldType);							
		}
		
		return null;
		
		}catch(Exception e) {
			throw new Exception("Error in visitDeclaration_Variable of codegen");
		}
	
	}

	@Override
	public Object visitExpression_Binary(Expression_Binary expression_Binary, Object arg) throws Exception {
		// TODO 
		
		try {
				expression_Binary.e0.visit(this, arg);
				expression_Binary.e1.visit(this, arg);
				
				
				if(expression_Binary.op == Kind.OP_PLUS) {
					mv.visitInsn(IADD);
				} else if(expression_Binary.op == Kind.OP_MINUS) {
					mv.visitInsn(ISUB);
				}else if(expression_Binary.op == Kind.OP_TIMES) {
					mv.visitInsn(IMUL);
				}else if(expression_Binary.op == Kind.OP_DIV) {
					mv.visitInsn(IDIV);
				}else if(expression_Binary.op == Kind.OP_MOD) {
					mv.visitInsn(IREM);
				}else if(expression_Binary.op == Kind.OP_POWER) {
					mv.visitMethodInsn(INVOKESTATIC, "java/lang/Math", "pow", "(DD)D", false);
					mv.visitMethodInsn(INVOKESTATIC, "java/lang/Integer", "parseInt", "(Ljava/lang/String;)I", false);
				}else if(expression_Binary.op == Kind.OP_OR) {
					mv.visitInsn(IOR);
				}else if(expression_Binary.op == Kind.OP_AND) {
					mv.visitInsn(IAND);
				}else {
					
					Label label1 = new Label();
					
					if(expression_Binary.op == Kind.OP_EQ) {
						mv.visitJumpInsn(IF_ICMPNE, label1);
					}else if(expression_Binary.op == Kind.OP_NEQ) {
						mv.visitJumpInsn(IF_ICMPEQ, label1);
					}else if(expression_Binary.op == Kind.OP_GE) {
						mv.visitJumpInsn(IF_ICMPLT, label1);
					}else if(expression_Binary.op == Kind.OP_LE) {
						mv.visitJumpInsn(IF_ICMPGT, label1);
					}else if(expression_Binary.op == Kind.OP_GT) {
						mv.visitJumpInsn(IF_ICMPLE, label1);
					}else if(expression_Binary.op == Kind.OP_LT) {
						mv.visitJumpInsn(IF_ICMPGE, label1);
					}
					
					//If condition is true
					mv.visitInsn(ICONST_1);
					//mv.visitLdcInsn(true);
					
					Label label2 = new Label();
					mv.visitJumpInsn(GOTO, label2);
					
					
					mv.visitLabel(label1);
					mv.visitInsn(ICONST_0);
					//mv.visitLdcInsn(false);
					
					mv.visitLabel(label2);
					
				}
				
				//CodeGenUtils.genLogTOS(GRADE, mv, expression_Binary.getTypeName());
				return null;
		}catch(Exception e) {
			throw new Exception("Exception in visitExpression_Binary of CodeGen");
		}
		//throw new UnsupportedOperationException();
//		CodeGenUtils.genLogTOS(GRADE, mv, expression_Binary.getType());
//		return null;
	}

	@Override
	public Object visitExpression_Unary(Expression_Unary expression_Unary, Object arg) throws Exception {
		// TODO 
		
		try {
				expression_Unary.e.visit(this, arg);
				
				if(expression_Unary.e.getTypeName() == Type.INTEGER) {
					
					if(expression_Unary.op == Kind.OP_PLUS) {
						
					}else if(expression_Unary.op == Kind.OP_MINUS) {
						mv.visitInsn(INEG);
					}else if(expression_Unary.op == Kind.OP_EXCL) {
					
						mv.visitLdcInsn(INTEGER.MAX_VALUE);
						mv.visitInsn(IXOR);
					}
					
				}else if(expression_Unary.e.getTypeName() == Type.BOOLEAN) {
					
					if(expression_Unary.op == Kind.OP_EXCL) {
						
						Label label1 = new Label();
						
						mv.visitJumpInsn(IFEQ, label1);
						
						mv.visitInsn(ICONST_0);
						
						Label label2 = new Label();
						
						mv.visitJumpInsn(GOTO, label2);
						
						mv.visitLabel(label1);
						mv.visitInsn(ICONST_1);
						
						mv.visitLabel(label2);
					}
				}
				
				//CodeGenUtils.genLogTOS(GRADE, mv, expression_Unary.getTypeName());
				return null;
		}catch(Exception e) {
			throw new Exception("Exception in visitExpression_Unary");
		}
		
		//throw new UnsupportedOperationException();
//		CodeGenUtils.genLogTOS(GRADE, mv, expression_Unary.getType());
//		return null;
	}

	// generate code to leave the two values on the stack
	@Override
	public Object visitIndex(Index index, Object arg) throws Exception {
		// TODO HW6
		
		try {
			
				index.e0.visit(this, arg);
				index.e1.visit(this, arg);
				
				if(index.isCartesian()) {
					
				}else {
					
					//r,a				
					
					mv.visitInsn(DUP2);
					//r,a,r,a
					
					mv.visitMethodInsn(INVOKESTATIC, "cop5556fa17/RuntimeFunctions", "cart_x", "(II)I", false);
					//r,a,x
					
					mv.visitInsn(DUP_X2);
					//x,r,a,x
					
					mv.visitInsn(POP);
					//x,r,a
					
					mv.visitMethodInsn(INVOKESTATIC, "cop5556fa17/RuntimeFunctions", "cart_y", "(II)I", false);
					//x,y
					
				}
				return null;
		}catch(Exception e) {
			throw new Exception("Exception in visitIndex of CodeGen");
		}
		
		//throw new UnsupportedOperationException();
	}

	@Override
	public Object visitExpression_PixelSelector(Expression_PixelSelector expression_PixelSelector, Object arg)
			throws Exception {
		// TODO HW6
		
		try {
				
				mv.visitFieldInsn(GETSTATIC, className, expression_PixelSelector.name, "Ljava/awt/image/BufferedImage;");
				
				expression_PixelSelector.index.visit(this, arg);
				
				mv.visitMethodInsn(INVOKESTATIC, "cop5556fa17/ImageSupport", "getPixel", "(Ljava/awt/image/BufferedImage;II)I", false);
				
				return null;
		}catch(Exception e) {
			throw new Exception("Exception in visitExpression_PixelSelector of CodeGen");
		}
		//throw new UnsupportedOperationException();
	}

	@Override
	public Object visitExpression_Conditional(Expression_Conditional expression_Conditional, Object arg)
			throws Exception {
		// TODO 
		
		try {
				expression_Conditional.condition.visit(this, arg);
				
				Label label1 = new Label();
				mv.visitJumpInsn(IFEQ, label1);
				
				expression_Conditional.trueExpression.visit(this, arg);
				
				Label label2 = new Label();
				
				mv.visitJumpInsn(GOTO, label2);
				
				mv.visitLabel(label1);
				expression_Conditional.falseExpression.visit(this, arg);
				
				mv.visitLabel(label2);
			
			//	CodeGenUtils.genLogTOS(GRADE, mv, expression_Conditional.trueExpression.getTypeName());
				return null;
		}catch(Exception e) {
			throw new Exception("Exception in visitExpression_Conditional of CodeGen ");
		}
		//throw new UnsupportedOperationException();
//		CodeGenUtils.genLogTOS(GRADE, mv, expression_Conditional.trueExpression.getType());
//		return null;
	}


	@Override
	public Object visitDeclaration_Image(Declaration_Image declaration_Image, Object arg) throws Exception {
		// TODO HW6
		
		try {
			
				cw.visitField(ACC_STATIC, declaration_Image.name, "Ljava/awt/image/BufferedImage;", null, null);
				
				if(declaration_Image.source!=null) {
					
					declaration_Image.source.visit(this, arg);
					
					if(declaration_Image.xSize != null) {
						declaration_Image.xSize.visit(this, arg);
						String owner = "java/lang/Integer";
						String name = "valueOf";
						String desc = "(I)Ljava/lang/Integer;";
						mv.visitMethodInsn(INVOKESTATIC, owner, name, desc, false);
					} else {
						
						mv.visitInsn(ACONST_NULL);
					}
					
					
					if(declaration_Image.ySize != null) {
						declaration_Image.ySize.visit(this, arg);
						String owner = "java/lang/Integer";
						String name = "valueOf";
						String desc = "(I)Ljava/lang/Integer;";
						mv.visitMethodInsn(INVOKESTATIC, owner, name, desc, false);
					} else {
						
						mv.visitInsn(ACONST_NULL);
					}	
					
					String owner = "cop5556fa17/ImageSupport";
					String name = "readImage";
					String desc =ImageSupport.readImageSig;
					
					mv.visitMethodInsn(INVOKESTATIC, owner, name, desc, false);	
				
				} 
				else {
					
					if(declaration_Image.xSize != null) {
						
						declaration_Image.xSize.visit(this, arg);
						
					} else {
						mv.visitFieldInsn(GETSTATIC, className, "DEF_X", "I");
						//mv.visitLdcInsn(new Integer(256));
					}
					
					if(declaration_Image.ySize != null) {
						declaration_Image.ySize.visit(this, arg);
					}else {
						
						mv.visitFieldInsn(GETSTATIC, className, "DEF_Y", "I");
						//mv.visitLdcInsn(new Integer(256));
						
					}
					
					String owner = "cop5556fa17/ImageSupport";
					String name = "makeImage";
					String desc = ImageSupport.makeImageSig;
					
					mv.visitMethodInsn(INVOKESTATIC, owner, name, desc, false);	
					
				}
				
				mv.visitFieldInsn(PUTSTATIC, className, declaration_Image.name, "Ljava/awt/image/BufferedImage;");
				
			
				return null;
		}catch(Exception e) {
			throw new Exception("Exception in visitDeclaration_Image of CodeGen");
		}
		//throw new UnsupportedOperationException();
	}
	
  
	@Override
	public Object visitSource_StringLiteral(Source_StringLiteral source_StringLiteral, Object arg) throws Exception {
		// TODO HW6
		
		try {
			
				mv.visitLdcInsn(source_StringLiteral.fileOrUrl);
				
				//mv.visitFieldInsn(GETSTATIC, className, source_StringLiteral.fileOrUrl, "Ljava/lang/String;");
				
			
				return null;
		}catch(Exception e) {
			throw new Exception("Exception in visitSource_StringLiteral of CodeGen");
		}
		
		//throw new UnsupportedOperationException();
	}

	

	@Override
	public Object visitSource_CommandLineParam(Source_CommandLineParam source_CommandLineParam, Object arg)
			throws Exception {
		// TODO 
		
		try {
				
			mv.visitVarInsn(ALOAD, 0);
			
			source_CommandLineParam.paramNum.visit(this, arg);
							
			mv.visitInsn(AALOAD);
			
				
				//mv.visitLdcInsn(commandLineArgs);
				
								
			return null;
		}catch(Exception e) {
			throw new Exception("Exception in visitSource_CommanLineParam of CodeGen");
		}
		
		//throw new UnsupportedOperationException();
	}

	@Override
	public Object visitSource_Ident(Source_Ident source_Ident, Object arg) throws Exception {
		// TODO HW6
		
		try {
			
				mv.visitFieldInsn(GETSTATIC, className,source_Ident.name, "Ljava/lang/String;");
			
				//mv.visitLdcInsn(source_Ident.name);
			
				return null;
		}catch(Exception e) {
			throw new Exception("Exception in visitSource_Ident in CodeGen");
		}
		
		//throw new UnsupportedOperationException();
	}


	@Override
	public Object visitDeclaration_SourceSink(Declaration_SourceSink declaration_SourceSink, Object arg)
			throws Exception {
		// TODO HW6
		try {
			
			String fieldName;
			String fieldType;
			Object initValue;
			FieldVisitor fv;
			
			fieldName = declaration_SourceSink.name;
			fieldType = "Ljava/lang/String;";
			
			fv = cw.visitField(ACC_STATIC, fieldName, fieldType, null, null);
			
			if(declaration_SourceSink.source != null){
				
				declaration_SourceSink.source.visit(this, arg);
				mv.visitFieldInsn(PUTSTATIC, className, fieldName, fieldType);
			}
			
				return null;
		}catch(Exception e) {
			throw new Exception("Exception in visitDeclaration_SourceSink of CodeGen");
		}
		
		//throw new UnsupportedOperationException();
	}
	


	@Override
	public Object visitExpression_IntLit(Expression_IntLit expression_IntLit, Object arg) throws Exception {
		// TODO 
		
		
		try {
			
			mv.visitLdcInsn(new Integer(expression_IntLit.value));
			//CodeGenUtils.genLogTOS(GRADE, mv, Type.INTEGER);
			return null;
		}catch(Exception e) {
			throw new Exception("Exception in visitExpression_IntLit of codegen");
		}

//		return null;
	}

	@Override
	public Object visitExpression_FunctionAppWithExprArg(
			Expression_FunctionAppWithExprArg expression_FunctionAppWithExprArg, Object arg) throws Exception {
		// TODO HW6
		
		try {
			
				String function = "";
				
				expression_FunctionAppWithExprArg.arg.visit(this, arg);
			
				if(expression_FunctionAppWithExprArg.function == Kind.KW_abs) {
					function = "abs";
				}else if(expression_FunctionAppWithExprArg.function == Kind.KW_log) {
					function = "log";
				}
				
				mv.visitMethodInsn(INVOKESTATIC, "cop5556fa17/RuntimeFunctions", function, "(I)I", false);	
			
				return null;
		}catch(Exception e) {
			throw new Exception("Exception in visitExpression_FunctionAppWithExprArg of CodeGen");
		}
		
		//throw new UnsupportedOperationException();
	}

	@Override
	public Object visitExpression_FunctionAppWithIndexArg(
			Expression_FunctionAppWithIndexArg expression_FunctionAppWithIndexArg, Object arg) throws Exception {
		// TODO HW6
		
		try {
			
				Index ind	= expression_FunctionAppWithIndexArg.arg;
			
				ind.e0.visit(this, arg);
				ind.e1.visit(this, arg);
			
				String function = "";
			
				if(expression_FunctionAppWithIndexArg.function == Kind.KW_cart_x) {
					function = "cart_x";
				}else if(expression_FunctionAppWithIndexArg.function == Kind.KW_cart_y) {
					function = "cart_y";
				}else if(expression_FunctionAppWithIndexArg.function == Kind.KW_polar_r) {
					function = "polar_r";					
				}else if(expression_FunctionAppWithIndexArg.function == Kind.KW_polar_a) {
					function = "polar_a";
				}
				
				mv.visitMethodInsn(INVOKESTATIC, "cop5556fa17/RuntimeFunctions", function, "(II)I", false);
			
				return null;
		}catch(Exception e) {
			throw new Exception("Exception in visitExpression_FunctionAppWithIndexArg of CodeGen");
		}
		//throw new UnsupportedOperationException();
	}

	@Override
	public Object visitExpression_PredefinedName(Expression_PredefinedName expression_PredefinedName, Object arg)
			throws Exception {
		// TODO HW6
		
		try {
			
				Kind kind = expression_PredefinedName.kind;
				if(kind == Kind.KW_DEF_X) {
					mv.visitFieldInsn(GETSTATIC, className, "DEF_X", "I");
				}else if(kind == Kind.KW_DEF_Y) {
					mv.visitFieldInsn(GETSTATIC, className, "DEF_Y", "I");
				}else if(kind == Kind.KW_Z) {
					mv.visitFieldInsn(GETSTATIC, className, "Z", "I");
				}else if(kind == Kind.KW_x) {
					mv.visitVarInsn(ILOAD,1);
				}else if(kind == Kind.KW_y) {
					mv.visitVarInsn(ILOAD,2);
				}else if(kind == Kind.KW_X) {
					mv.visitVarInsn(ILOAD,3);
				}else if(kind == Kind.KW_Y) {
					mv.visitVarInsn(ILOAD,4);
				}else if(kind == Kind.KW_r) {
					mv.visitVarInsn(ILOAD,1);
					mv.visitVarInsn(ILOAD,2);
					mv.visitMethodInsn(INVOKESTATIC, "cop5556fa17/RuntimeFunctions", "polar_r", "(II)I", false);					
				}else if(kind == Kind.KW_a) {
					mv.visitVarInsn(ILOAD,1);
					mv.visitVarInsn(ILOAD,2);
					mv.visitMethodInsn(INVOKESTATIC, "cop5556fa17/RuntimeFunctions", "polar_a", "(II)I", false);
				}else if(kind == Kind.KW_R) {
					mv.visitVarInsn(ILOAD,7);
				}else if(kind == Kind.KW_A) {
					mv.visitVarInsn(ILOAD,8);
				}
			
				return null;
		}catch(Exception e) {
			throw new Exception("Exception in visitExpression_PredefinedName of CodeGen");
		}
		//throw new UnsupportedOperationException();
	}

	/** For Integers and booleans, the only "sink"is the screen, so generate code to print to console.
	 * For Images, load the Image onto the stack and visit the Sink which will generate the code to handle the image.
	 */
	@Override
	public Object visitStatement_Out(Statement_Out statement_Out, Object arg) throws Exception {
		// TODO in HW5:  only INTEGER and BOOLEAN
		// TODO HW6 remaining cases
		
		try {
			
			
		//	statement_Out.sink.visit(this, arg);
			
				
				
				String tp = "";
				
				if(statement_Out.getDec().getTypeName() == Type.INTEGER) {
					tp = "I";
					
					mv.visitFieldInsn(GETSTATIC, "java/lang/System", "out", "Ljava/io/PrintStream;");
					
					
					
					mv.visitFieldInsn(GETSTATIC, className, statement_Out.name, tp);
					
					CodeGenUtils.genLogTOS(GRADE, mv, statement_Out.getDec().getTypeName());
					
					//mv.visitLdcInsn(statement_Out.sink.toString());
					//mv.visitMethodInsn(INVOKEVIRTUAL, "java/io/PrintStream", "println", "(Ljava/lang/String;)V");
					mv.visitMethodInsn(INVOKEVIRTUAL, "java/io/PrintStream", "println", "(I)V", false);
					
				}else if(statement_Out.getDec().getTypeName() == Type.BOOLEAN){
					tp = "Z";
					
					mv.visitFieldInsn(GETSTATIC, "java/lang/System", "out", "Ljava/io/PrintStream;");
					
					
					
					mv.visitFieldInsn(GETSTATIC, className, statement_Out.name, tp);
					
					CodeGenUtils.genLogTOS(GRADE, mv, statement_Out.getDec().getTypeName());
					
					//mv.visitLdcInsn(statement_Out.sink.toString());
					//mv.visitMethodInsn(INVOKEVIRTUAL, "java/io/PrintStream", "println", "(Ljava/lang/String;)V");
					mv.visitMethodInsn(INVOKEVIRTUAL, "java/io/PrintStream", "println", "(Z)V", false);
				} else if(statement_Out.getDec().getTypeName() == Type.IMAGE) {
					
					//mv.visitFieldInsn(GETSTATIC, "java/lang/System", "out", "Ljava/io/PrintStream;");
										
					mv.visitFieldInsn(GETSTATIC, className, statement_Out.name, "Ljava/awt/image/BufferedImage;");
					
					
					mv.visitMethodInsn(INVOKESTATIC, "cop5556fa17/RuntimeLog", "globalLogAddImage", "("+ImageSupport.ImageDesc + ")V", false);
					//CodeGenUtils.genLogTOS(GRADE, mv, statement_Out.getDec().getTypeName());
					
					mv.visitFieldInsn(GETSTATIC, className, statement_Out.name, "Ljava/awt/image/BufferedImage;");
					
					statement_Out.sink.visit(this, arg);	
					
					
				}
								
			
			return null;
		}catch(Exception e) {
			//throw new Exception("Exception in visitStatement_Out of CodeGen");
			throw new Exception(e);
		}
		
		//throw new UnsupportedOperationException();
	}

	/**
	 * Visit source to load rhs, which will be a String, onto the stack
	 * 
	 *  In HW5, you only need to handle INTEGER and BOOLEAN
	 *  Use java.lang.Integer.parseInt or java.lang.Boolean.parseBoolean 
	 *  to convert String to actual type. 
	 *  
	 *  TODO HW6 remaining types
	 */
	@Override
	public Object visitStatement_In(Statement_In statement_In, Object arg) throws Exception {
		// TODO (see comment )
		
		try {
				statement_In.source.visit(this, arg);
				
				if(statement_In.getDec().getTypeName() == Type.INTEGER) {
					mv.visitMethodInsn(INVOKESTATIC, "java/lang/Integer", "parseInt", "(Ljava/lang/String;)I", false);
					mv.visitFieldInsn(PUTSTATIC, className, statement_In.name, "I");
				}else if(statement_In.getDec().getTypeName() == Type.BOOLEAN) {
					mv.visitMethodInsn(INVOKESTATIC, "java/lang/Boolean", "parseBoolean", "(Ljava/lang/String;)Z", false);
					mv.visitFieldInsn(PUTSTATIC, className, statement_In.name, "Z");
				}else if(statement_In.getDec().getTypeName() == Type.IMAGE) {
					
					Declaration_Image declaration = (Declaration_Image)statement_In.getDec();
					
					if(declaration.xSize != null) {
						declaration.xSize.visit(this, arg);
						String owner = "java/lang/Integer";
						String name = "valueOf";
						String desc = "(I)Ljava/lang/Integer;";
						mv.visitMethodInsn(INVOKESTATIC, owner, name, desc, false);
					} else {
						
						mv.visitInsn(ACONST_NULL);
					}
					
					
					if(declaration.ySize != null) {
						declaration.ySize.visit(this, arg);
						String owner = "java/lang/Integer";
						String name = "valueOf";
						String desc = "(I)Ljava/lang/Integer;";
						mv.visitMethodInsn(INVOKESTATIC, owner, name, desc, false);
					} else {
						
						mv.visitInsn(ACONST_NULL);
					}	
					
					String owner = "cop5556fa17/ImageSupport";
					String name = "readImage";
					String desc =ImageSupport.readImageSig;
					
					mv.visitMethodInsn(INVOKESTATIC, owner, name, desc, false);	
					
					mv.visitFieldInsn(PUTSTATIC, className, statement_In.name, "Ljava/awt/image/BufferedImage;");					
					
				}
					
				
				return null;
		}catch(Exception e) {
			throw new Exception("Exception in visitStatement_In of CodeGen");
		}
		
		//throw new UnsupportedOperationException();
	}

	
	/**
	 * In HW5, only handle INTEGER and BOOLEAN types.
	 */
	@Override
	public Object visitStatement_Assign(Statement_Assign statement_Assign, Object arg) throws Exception {
		//TODO  (see comment)
		
		try {
			
				if(statement_Assign.lhs.getTypeName() == Type.INTEGER || statement_Assign.lhs.getTypeName() == Type.BOOLEAN) {
					statement_Assign.e.visit(this, arg);
					statement_Assign.lhs.visit(this, arg);
				}else {
					
					
					mv.visitFieldInsn(GETSTATIC, className, statement_Assign.lhs.name, "Ljava/awt/image/BufferedImage;");
					mv.visitMethodInsn(INVOKESTATIC, "cop5556fa17/ImageSupport", "getX", "(Ljava/awt/image/BufferedImage;)I", false);
					mv.visitVarInsn(ISTORE, 3);

					mv.visitFieldInsn(GETSTATIC, className, statement_Assign.lhs.name, "Ljava/awt/image/BufferedImage;");
					mv.visitMethodInsn(INVOKESTATIC, "cop5556fa17/ImageSupport", "getY", "(Ljava/awt/image/BufferedImage;)I", false);
					mv.visitVarInsn(ISTORE, 4);
					
					
					
					
					mv.visitInsn(ICONST_0);
					mv.visitVarInsn(ISTORE, 1);
					

					Label lable_checkx = new Label();
					mv.visitJumpInsn(GOTO, lable_checkx);
					
					Label lable_starty = new Label();
					mv.visitLabel(lable_starty);
										
					mv.visitInsn(ICONST_0);
					mv.visitVarInsn(ISTORE, 2);
					
					Label lable_checky = new Label();
					mv.visitJumpInsn(GOTO, lable_checky);
					
					Label lable_processpixel = new Label();
					mv.visitLabel(lable_processpixel);
					
					statement_Assign.e.visit(this, arg);
					statement_Assign.lhs.visit(this, arg);
					
					
					Label lable_incrementy = new Label();
					mv.visitLabel(lable_incrementy);
					mv.visitIincInsn(2,1);
					mv.visitLabel(lable_checky);
					mv.visitVarInsn(ILOAD,2); 
					mv.visitVarInsn(ILOAD,4); 
					mv.visitJumpInsn(IF_ICMPLT, lable_processpixel);

					Label lable_incrementx = new Label();
					mv.visitLabel(lable_incrementx);					
					mv.visitIincInsn(1,1);
					mv.visitLabel(lable_checkx);
					mv.visitVarInsn(ILOAD,1);
					mv.visitVarInsn(ILOAD,3);	
					mv.visitJumpInsn(IF_ICMPLT, lable_starty);
															
				}
				
				
				
				return null;
		}catch(Exception e) {
			throw new Exception("Exception in visitStatement_Assign in codegen");
		}
	}

	/**
	 * In HW5, only handle INTEGER and BOOLEAN types.
	 */
	@Override
	public Object visitLHS(LHS lhs, Object arg) throws Exception {
		//TODO  (see comment)
		
		try {
									
			String tp = "";
		
				if(lhs.getTypeName() == Type.INTEGER) {
					tp = "I";
					mv.visitFieldInsn(PUTSTATIC, className, lhs.name, tp);
				}else if(lhs.getTypeName() == Type.BOOLEAN){
					tp = "Z";
					mv.visitFieldInsn(PUTSTATIC, className, lhs.name, tp);
				}else if(lhs.getTypeName() == Type.IMAGE) {
					mv.visitFieldInsn(GETSTATIC, className, lhs.name, "Ljava/awt/image/BufferedImage;");
					
					mv.visitVarInsn(ILOAD, 1);
					mv.visitVarInsn(ILOAD, 2);
					
					String owner = "cop5556fa17/ImageSupport";
					String name = "setPixel";
					String desc = "(ILjava/awt/image/BufferedImage;II)V";
					mv.visitMethodInsn(INVOKESTATIC, owner, name, desc, false);
					
				}
				
				
			
			return null;
		}catch(Exception e) {
			throw new Exception("Exception in visitLHS of codegen");
		}
		
		//throw new UnsupportedOperationException();
	}
	

	@Override
	public Object visitSink_SCREEN(Sink_SCREEN sink_SCREEN, Object arg) throws Exception {
		//TODO HW6
		try {
				String owner = "cop5556fa17/ImageSupport";
				String name = "makeFrame";
				String desc = "(Ljava/awt/image/BufferedImage;)Ljavax/swing/JFrame;";
				mv.visitMethodInsn(INVOKESTATIC, owner, name, desc, false);
			
				mv.visitInsn(POP);
				return null;
		}catch(Exception e) {
			throw new Exception("Exception in visitSink_SCREEN of CodeGen");
		}
		//throw new UnsupportedOperationException();
	}

	@Override
	public Object visitSink_Ident(Sink_Ident sink_Ident, Object arg) throws Exception {
		//TODO HW6
		
		try {
			
				mv.visitFieldInsn(GETSTATIC, className, sink_Ident.name, "Ljava/lang/String;");
							
				//mv.visitLdcInsn(sink_Ident.name);
				
				mv.visitMethodInsn(INVOKESTATIC, "cop5556fa17/ImageSupport", "write", "(Ljava/awt/image/BufferedImage;Ljava/lang/String;)V", false);
				
				return null;
				
		}catch(Exception e) {
			throw new Exception("Exception in visitSink_Ident of CodeGen");
		}
	//	throw new UnsupportedOperationException();
	}

	@Override
	public Object visitExpression_BooleanLit(Expression_BooleanLit expression_BooleanLit, Object arg) throws Exception {
		//TODO
		
		try {
			
			//	if(expression_BooleanLit.value == true) {
			//		mv.visitInsn(ICONST_1);
			//	}else {
			//		mv.visitInsn(ICONST_0);
			//	}
				mv.visitLdcInsn(new Boolean(expression_BooleanLit.value));
				//CodeGenUtils.genLogTOS(GRADE, mv, Type.BOOLEAN);
				
				return null;
		}catch(Exception e) {
			throw new Exception("Exception in visitExpression_BooleanLit in codegen");
		}
		
		//throw new UnsupportedOperationException();
//		CodeGenUtils.genLogTOS(GRADE, mv, Type.BOOLEAN);
//		return null;
	}

	@Override
	public Object visitExpression_Ident(Expression_Ident expression_Ident,
			Object arg) throws Exception {
		//TODO
		try {
				String tp = "";
				if(expression_Ident.getTypeName() == Type.INTEGER) {
					tp = "I";
				}else if(expression_Ident.getTypeName() == Type.BOOLEAN) {
					tp = "Z";
				}
				
				mv.visitFieldInsn(GETSTATIC, className, expression_Ident.name, tp);
				
			//	CodeGenUtils.genLogTOS(GRADE, mv, expression_Ident.getTypeName());
				
				return null;
		}catch(Exception e) {
			throw new Exception("Exception in visitExpression_Ident in codegen");
		}
		
		//throw new UnsupportedOperationException();
//		CodeGenUtils.genLogTOS(GRADE, mv, expression_Ident.getType());
//		return null;
	}

}
